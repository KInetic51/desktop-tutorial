# custom views
from django.http import HttpResponse
from django.shortcuts import render, redirect
from app1.models import Resource
from django.db.models import Q  #for complex queries
from django.db.models import Count

from django.http import JsonResponse
from django.shortcuts import get_object_or_404

def index(request):
    resources = Resource.objects.all()
    total_len = len(resources)

    #  identifying favrouities
    favorites = Resource.objects.filter(fav=True)
    print(">>",favorites)

    #  identify unique categories
    unique_categories = Resource.objects.values('category').annotate(entry_count=Count('category')).order_by('-entry_count')

    params = {"resources":resources, "favorites":favorites, "unique_categories":unique_categories}
    return render(request, "KINE.html", params)

def search(request):
    # Getting the query from search s ection
    query = request.GET.get("query","default")
    if query:
        resources = Resource.objects.filter(
            Q(title__icontains=query) | Q(authour__icontains=query) | Q(category__icontains=query)
        )
    else:
        resources = None

    
    params={"resources":resources}
    return render(request, "KINE.html", params)



def add (request):

    query_title = request.POST.get("title","default")
    query_authour = request.POST.get("authour","default")
    query_category = request.POST.get("category","default")
    
    # comitting changes
    ready_resource = Resource(title=query_title, authour=query_authour, category=query_category)
    ready_resource.save()

    params = {}

    # return HttpResponse(status=202)
    return redirect('http://127.0.0.1:8000/#admin')



def toggle_favorite_ajax(request, resource_id):
    if request.method == "POST":
        resource = get_object_or_404(Resource, id=resource_id)
        resource.fav = not resource.fav
        resource.save()
        return JsonResponse({'success': True, 'is_fav': resource.fav})
    return JsonResponse({'success': False}, status=400)