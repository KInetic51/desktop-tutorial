
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path("search/",views.search, name="search"), # search end point
    path("add/",views.add, name="add"), # search end point
    path('toggle-favorite/<int:resource_id>/', views.toggle_favorite_ajax, name='toggle_favorite_ajax'),
]
