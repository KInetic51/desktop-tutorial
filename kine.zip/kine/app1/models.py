from django.db import models

# create your models here
class Resource (models.Model):
    id = models.AutoField
    title = models.CharField(max_length=50, default="")
    authour = models.CharField(max_length=50, default="")
    category = models.CharField(max_length=50, default="")
    # file = models.ImageField(upload_to="app1/images", default="")

    # new fields
    fav = models.BooleanField(default=False)

    def __str__(self):
        return self.title
