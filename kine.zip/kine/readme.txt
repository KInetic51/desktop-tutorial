# sqlite3 table columns
- sno
- title
- author
- file link